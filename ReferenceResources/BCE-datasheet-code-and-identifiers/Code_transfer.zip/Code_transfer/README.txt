This software is licensed under the BSD-3-Clause license.  See license.txt for
details.

Some code contained within is copyright under the GNU GPL v3 license, namely the
'Code_pre/LDA.py' script.  This is based on the original 'onlineldavb.py' script
which is licensed under GNU GPL v3 by Matthew D. Hoffman.

Many of the file locations are set in 'Settings/settings.py'.  Change the
settings there to properly set up all scripts.

The Proc folder should contain much of the data needed to execute the
algorithm. As most data is license restricted, most of these files will need to
be filled in by researchers.

The scripts rely on the brown corpus and punkt as provided by NLTK.  These need
to be downloaded separately, directly using the nltk package.

The code contained herein is sufficient to generate LDA topics on 10-K text
as was done in the paper "What are you saying? Using topic to detect financial
misreporting."

The primary script is located in z_log/main.sh and can be run using bash.  All code works under Python 2.7; some changes are needed to make it Python 3.* compatible.  Use of Cython is also required.