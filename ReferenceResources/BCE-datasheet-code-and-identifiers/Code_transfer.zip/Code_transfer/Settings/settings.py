# All settings are listed below.  Please set these to match the computer and
# operating system you plan to run the scripts on.  Use the same conventions as
# those of the operating system you plan to run the scripts on.  That is, file
# paths should include '/' on Linux and Mac, and '\' on Windows.

# Directory to store data files in.
DATA_PATH = '/path/to/data/storage/'
# Scratch disk location
SCRATCH_PATH = '/path/to/Scratch/Disk'  # Optional
# Whether intermediary files are on the scratch disk, and scratch folder name
PROC_ON_SCRATCH = False
PROJECT_NUMBER = 'root'
PROJECT_PATH = '/path/to/project/root/'
if PROC_ON_SCRATCH:
	PROC_PATH = SCRATCH_PATH + PROJECT_NUMBER + '/'
else:
	PROC_PATH = PROJECT_PATH + 'Proc/'

# Number of logical cores (i.e., threads) to use
threads = 12  # Set this to the number of threads on your computer

# GLOBAL VARIABLES (in all caps)
GLOVE_DATA = '840B'

# End of settings

