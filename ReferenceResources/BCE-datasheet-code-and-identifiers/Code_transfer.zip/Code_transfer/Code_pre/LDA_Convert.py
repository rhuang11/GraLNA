#!/usr/bin/python
#
# Copyright (C) 2014 Richard M. Crowley
# If using, please cite Brown, Crowley and Elliott (2014 Working).
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# Portions copyright (C) 2010  Matthew D. Hoffman
# This code is a significantly modified version of Matthew D. Hoffman's
# implementation of online LDA for Wikipedia.
#

# Custom libraries
import os
import sys
sys.path.insert(0, '../Libraries/Libraries')
import ScriptUtils

# Imports shared variables and settings
sys.path.insert(0,'../Settings')
import settings

from collections import Counter
import csv
import itertools
import multiprocessing
import pickle
import re
import time
import traceback

import numpy as np


def worker_data(inqueue, outqueue):
    try:
        print((os.getpid(), "is starting"))
        while True:
            while inqueue.empty() is True:
                time.sleep(0.1)
            (textfiles, ids, lambda_m, year) = inqueue.get(True)
            if year == 0:
                print((os.getpid(), 'is shutting down'))
                return
            outrows = []
            for textfile in textfiles:
                outrow = []
                filing = textfile[1][0:-5]
                company = filing[0:10]
                outrow.append(filing)
                outrow.append(company)
                if str(year)[2:4] == re.findall('(?<=\-)[0-9]{2}(?=\-)',
                                                filing)[0]:
                    outrow.append(1)
                else:
                    outrow.append(0)
                # calculate the topic values
                with open(textfile[0] + '/' + textfile[1], 'r') as f:
                    counter = pickle.load(f)
                temp = Counter(dict(itertools.izip(ids, [1] * len(ids)))) \
                    + counter
                temp2 = zip(temp.keys(), temp.values())
                temp2 = sorted(temp2, key=lambda x: x[0])
                tids, tvals = zip(*temp2)
                outrow += list(np.sum(np.array(tvals) * lambda_m - lambda_m, 1))
                outrows.append(outrow)
            outqueue.put(outrows)
    except:
        print(('Permanent fault: %s' % (traceback.format_exc())))
        print(textfile)
    return


def printtopics():
    """
    Displays topics fit by onlineldavb.py. The first column gives the
    (expected) most prominent words in the topics, the second column
    gives their (expected) relative prominence.
    """
    # generate indir
    indir = os.path.abspath(os.path.join(ScriptUtils.getScriptPath(), '..'))\
        + '/'
    processes = 1
    if len(sys.argv) > 1:
        processes = int(sys.argv[1])  # 6
    filetype = '10-K'
    if len(sys.argv) > 2:
        filetype = sys.argv[2]  # 10-K
    yearstep = 5
    if len(sys.argv) > 3:
        yearstep = int(sys.argv[3])  # 5
    stopword = '50-0-500-100'
    if len(sys.argv) > 4:
        stopword = sys.argv[4]  # 50-0-500-100
    topics = 20
    if len(sys.argv) > 5:
        topics = int(sys.argv[5])  # 20
    yearstart = 1994
    if len(sys.argv) > 6:
        yearstart = int(sys.argv[6])  # 1994
    yearend = 2012
    if len(sys.argv) > 7:
        yearend = int(sys.argv[7])  # 2012
    test = 0
    if len(sys.argv) > 8:
        test = int(sys.argv[8])
    if test > 0:
        indir = indir + 'Test/'

    vocabpath = os.path.join(settings.PROC_PATH, 'Intermediary', filetype + '_' +
                             str(yearstep) + '_' + stopword)
    lambdapath = os.path.join(settings.PROC_PATH, 'Intermediary', filetype + '_' +
                              str(yearstep) + '_' + stopword + '_LDA' +
                              str(topics))

    inqueue = multiprocessing.Queue()
    outqueue = multiprocessing.Queue()
    the_pool = multiprocessing.Pool(processes, worker_data, (inqueue,
                                                             outqueue,))

    # By window
    for testyear in xrange(yearstart + yearstep if yearstep > 0 else yearend,
                           yearend + 1):
        with open(vocabpath + '/stopwords_' + str(testyear) + '.stop', 'r') \
                as f:
            vocab = pickle.load(f)
        with open(lambdapath + '/' + str(testyear) + '/lambda.dat', 'r') as f:
            testlambda = np.loadtxt(f)
        vocabwords = vocab.keys()
        vocabwords.reverse()
        vocabids = vocab.values()
        vocabids.reverse()

        textout1 = ''
        textout2 = ''
        lambdafull = []
        for k in range(0, len(testlambda)):
            # Get full list of topic weightings
            lambdak = list(testlambda[k, :])
            lambdak = lambdak / np.sum(lambdak)
            lambdafull.append(lambdak)
            # Zip together lambda values and ids
            temp = zip(lambdak, range(1, len(lambdak) + 1))
            temp2 = sorted(temp, key=lambda x: x[0], reverse=True)

            # Text to print to have a readable version of topics
            textout1 += 'topic %d:\n' % (k)
            textout2 += 'topic %d:\n' % (k)
            for i in xrange(0, 50):
                if i < 10:
                    textout2 += '%20s  \t---\t  %.4f\n' % (vocabwords[vocabids.index(temp2[i][1])], temp2[i][0])
                textout1 += '%20s  \t---\t  %.4f\n' % (vocabwords[vocabids.index(temp2[i][1])],
                                                       temp2[i][0])
        lambdafull = np.array(lambdafull)
        with open(lambdapath + '/' + str(testyear) + '/topics50.txt', 'w')\
                as f:
            f.write(textout1)
        with open(lambdapath + '/' + str(testyear) + '/topics10.txt', 'w')\
                as f:
            f.write(textout2)
        # Use lambdafull along with cores to build data file
        files = []
        for root, dirs, filenames in os.walk(os.path.join(vocabpath,
                                                          str(testyear))):
            for f in filenames:
                files.append([root, f])
        fed = 0
        processed = 0
        notdonereading = 1
        tofeed = len(files)
        tofeed_str = str(tofeed)
        log = open(os.path.join(settings.PROC_PATH, 'Data_Files', 'LDA', filetype + '_' +
                                str(yearstep) + '_' + stopword + '_LDA' +
                                str(topics) + '_' + str(testyear) + '.csv'),
                   'w')
        writer = csv.writer(log)
        writer.writerow(['Filing', 'Company', 'Test'] + ['Topic_' + str(i) for
                                                         i in xrange(1, topics
                                                                     + 1)])
        while processed < tofeed:
            while inqueue.qsize() < processes * 4 * notdonereading:
                textfiles = []
                for i in xrange(fed, min(tofeed, fed + 50)):
                    textfiles.append(files[i])
                fed = min(tofeed, fed + 50)
                inqueue.put((textfiles, vocabids, lambdafull, testyear))
                sys.stdout.write('Year: ' + str(testyear) + ',Docs: ' +
                                 tofeed_str + ', Fed: ' + str(fed).ljust(6) +
                                 ', Proc: ' + str(processed).ljust(6) + '\r')
                sys.stdout.flush()
                if fed == tofeed:
                    notdonereading = 0
            if outqueue.empty() is not True:
                outrows = outqueue.get(True)
                processed += len(outrows)
                writer.writerows(outrows)
                sys.stdout.write('Year: ' + str(testyear) + ',Docs: ' +
                                 tofeed_str + ', Fed: ' + str(fed).ljust(6) +
                                 ', Proc: ' + str(processed).ljust(6) + '\r')
                sys.stdout.flush()
        log.close()
    for i in xrange(0, processes):
        inqueue.put((0, 0, 0, 0))
    time.sleep(3)
    the_pool.close()
    print('pool closed')
    print('Everything processed')

if __name__ == '__main__':
    printtopics()
