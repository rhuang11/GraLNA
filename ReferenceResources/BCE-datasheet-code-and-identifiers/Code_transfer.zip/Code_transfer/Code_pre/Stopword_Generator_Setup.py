from distutils.core import setup
from Cython.Build import cythonize

setup(
  name = 'Stopword Generator',
  ext_modules = cythonize("Stopword_Generator.pyx"),
)
