from distutils.core import setup
from Cython.Build import cythonize

setup(
  name = 'Word counter',
  ext_modules = cythonize("Word_Counts.pyx"),
)
