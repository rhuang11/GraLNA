#!/usr/bin/python
#
# Copyright (C) 2019 Richard M. Crowley
# If using, please cite Brown, Crowley and Elliott (2019 JAR).
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# Portions copyright (C) 2010  Matthew D. Hoffman
# This code is a significantly modified version of Matthew D. Hoffman's
# implementation of online LDA for Wikipedia.
#

# Custom libraries
import os
import sys
sys.path.insert(0, '../Libraries/Libraries')
import ScriptUtils
import onlineldavb

# Imports shared variables and settings
sys.path.insert(0,'../Settings')
import settings

# Get other internal modules
import multiprocessing
import pickle
import random
import time
import traceback

# Get external modules
import numpy

# import filingunrandom_ex


def worker_io(inqueue, outqueue):
    try:
        print(os.getpid(), "is starting")
        while True:
            while inqueue.empty() is True:
                time.sleep(0.1)
            (shutdown, textfiles) = inqueue.get()
            if shutdown:
                print(os.getpid(), 'io shutting down')
                return
            docs = []
            for textfile in textfiles:
                with open(textfile, 'r') as f:
                    docs.append(pickle.load(f))
            outqueue.put(docs)
    except:
        # print('%s: %s' % (filename, traceback.format_exc()))
        print('Permanent fault: %s' % (traceback.format_exc()))
    return


def worker_calc(initqueue, inqueue2, outqueue2):
    try:
        while True:
            print(os.getpid(), "is starting")
            # Wait for initialization variables to be passed
            while initqueue.empty():
                time.sleep(0.1)
            # Initialize the algorithm with alpha=1/K, eta=1/K, tau_0=1024
            # kappa=0.7
            (vocab, K, D, y, batchsize, filepath) = initqueue.get(True)
            if filepath == 0:
                print(os.getpid(), 'calc shutting down')
                return
            filepath = os.path.join(filepath, str(y))
            if not os.path.exists(filepath):
                os.makedirs(filepath)

            if vocab == 0:
                print(os.getpid(), 'calc is shutting down')
                return
            olda = onlineldavb.OnlineLDA(vocab, K, D, 1./K, 1./K, 1024., 0.7)

            processing = 1
            iteration = 0
            while processing:
                while inqueue2.empty():
                    time.sleep(0.1)
                (state, docs) = inqueue2.get(True)
                iteration += 1
                if state:
                    # Give them to online LDA
                    (gamma, bound) = olda.update_lambda(docs)
                    # Compute an estimate of held-out perplexity
                    wordcts = [i.values() for i in docs]
                    perwordbound = bound * len(docs) / (D * sum(map(sum,
                                                                    wordcts)))
                    sys.stdout.write('\n%d : %d of %d:  rho_t = %f,  held-out perplexity estimate = %f\n' % \
                        (y, iteration, D/batchsize, olda._rhot, numpy.exp(-perwordbound)))
                    sys.stdout.flush()
                    # Flag as batch processed
                    outqueue2.put((1))
                    if iteration == D/batchsize:
                        numpy.savetxt(filepath + '/lambda.dat', olda._lambda)
                        # Flag as finished
                        numpy.savetxt(filepath + '/gamma.dat', gamma)
                        outqueue2.put((0))
                        processing = 0
                else:
                    print('Shutting down calc')
    except:
        # print('%s: %s' % (filename, traceback.format_exc()))
        print('Permanent fault: %s' % (traceback.format_exc()))
    return


def lda():
    # generate indir
    indir = os.path.abspath(os.path.join(ScriptUtils.getScriptPath(), '..'))\
        + '/'
    # Number of processes to spawn
    processes = 1
    if len(sys.argv) > 1:
        processes = int(sys.argv[1])  # 6
    # Stopword files to use
    filetype = '10-K'
    if len(sys.argv) > 2:
        filetype = sys.argv[2]  # 10-K  10-Ki  10-K_MDA
    # Window length to use
    yearstep = 5
    if len(sys.argv) > 3:
        yearstep = int(sys.argv[3])  # 5
    stopwordtype = '50-0-500-100'
    if len(sys.argv) > 4:
        stopwordtype = sys.argv[4]  # 50-0-500-100
    # Number of topics
    K = 20
    if len(sys.argv) > 5:
        K = int(sys.argv[5])  # 20
    # First year in the sample
    yearstart = 1994
    if len(sys.argv) > 6:
        yearstart = int(sys.argv[6])  # 1994
    # Last year in the sample
    yearend = 2012
    if len(sys.argv) > 7:
        yearend = int(sys.argv[7])  # 2012
    test = 0
    if len(sys.argv) > 8:
        test = int(sys.argv[8])
    if test > 0:
        indir = indir + 'Test/'
    # local path
    filetype = filetype + '_' + str(yearstep) + '_' + stopwordtype

    # Set up multiprocessing
    inqueue = multiprocessing.Queue()
    outqueue = multiprocessing.Queue()
    inqueue2 = multiprocessing.Queue()
    initqueue = multiprocessing.Queue()
    outqueue2 = multiprocessing.Queue()
    the_pool = multiprocessing.Pool(processes, worker_io, (inqueue, outqueue,))
    the_pool2 = multiprocessing.Pool(1, worker_calc, (initqueue, inqueue2,
                                                      outqueue2,))

    # The number of documents to analyze each iteration
    for testyear in xrange(yearstart + yearstep if yearstep > 0 else yearend,
                           yearend + 1):
        testcode = '-' + str(testyear)[2:4] + '-'
        print(testyear)
        # Initialize
        files = []
        # Determine files, load indexes
        print('Initializing files and indexes')
        temppath = os.path.join(settings.PROC_PATH, 'Intermediary', filetype, str(testyear))
        for root, dirs, filenames in os.walk(temppath):
            for f in filenames:
                if testcode not in f or yearstep == 0:
                    files.append([root, f])
        random.shuffle(files)
        batchsize = 100
        # The total number of documents
        D = len(files)
        # Our vocabulary
        with open(os.path.join(settings.PROC_PATH, 'Intermediary', filetype, 'stopwords_' +
                  str(testyear) + '.stop'), 'r') as f:
            vocab = pickle.load(f).keys()

        LDApath = os.path.join(settings.PROC_PATH, 'Intermediary', filetype + '_LDA' +
                               str(K))
        if not os.path.exists(LDApath):
            os.makedirs(LDApath)
        # Pass initialization to LDA process
        initqueue.put((vocab, K, D, testyear, batchsize, LDApath))

        # Run until we've seen D documents. (Feel free to interrupt *much*
        # sooner than this.)
        fed = 0
        tobatch = D/batchsize
        tofeed = tobatch * batchsize
        tofeed_str = str(tofeed)
        notdonereading = 1
        batches = 0
        batchdone = 0
        docset = []
        working = 1
        # Main loop
        while working:
            while inqueue.qsize() < processes * 4 * notdonereading and \
                    outqueue.qsize() <= 2 * processes and batches - 5 <= \
                    batchdone:
                textfiles = []
                for i in xrange(fed, min(tofeed, fed + batchsize)):
                    textfiles.append(files[fed][0] + '/' + files[fed][1])
                inqueue.put((0, textfiles))
                fed = min(tofeed, fed + batchsize)
                sys.stdout.write('Docs: ' + tofeed_str + ', Fed: ' +
                                 str(fed).ljust(5) + '\r')
                sys.stdout.flush()
                if fed == tofeed:
                    notdonereading = 0
            if outqueue.empty() is not True and batches - 5 <= batchdone:
                docset = outqueue.get(True)
                inqueue2.put((1, docset))
                batches += 1
            if outqueue2.empty() is not True:
                (state) = outqueue2.get(True)
                if state:
                    batchdone += 1
                else:
                    working = 0
        # Endwhile
    # Endfor
    for i in xrange(0, processes):
        inqueue.put((1, 0))
    initqueue.put((0, 0, 0, 0, 0, 0))
    time.sleep(3)
    the_pool.close()
    the_pool2.close()
    print('Pools closed')
    print('Everything processed')

# End up getting topics using the lambda files

if __name__ == '__main__':
    lda()
