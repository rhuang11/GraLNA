# Custom libraries
import os
import sys
sys.path.insert(0, '../Libraries/Libraries')
import ScriptUtils

# Imports shared variables and settings
sys.path.insert(0,'../Settings')
import settings

import csv
import pandas as pd
import statsmodels.formula.api as smf


def stats():
    # generate indir
    indir = os.path.abspath(os.path.join(ScriptUtils.getScriptPath(), '..'))\
        + '/'
    filetype = '10-K'
    if len(sys.argv) > 1:
        filetype = sys.argv[1]  # 10-K
    yearstep = 5
    if len(sys.argv) > 2:
        yearstep = int(sys.argv[2])  # 5
    stopword = '50-0-500-100'
    if len(sys.argv) > 3:
        stopword = sys.argv[3]  # 50-0-500-100
    topics = 20
    if len(sys.argv) > 4:
        topics = int(sys.argv[4])  # 20
    yearstart = 1994
    if len(sys.argv) > 5:
        yearstart = int(sys.argv[5])  # 1994
    yearend = 2012
    if len(sys.argv) > 6:
        yearend = int(sys.argv[6])  # 2012
    test = 0
    if len(sys.argv) > 7:
        test = int(sys.argv[7])  # 0
    if test > 0:
        indir = indir + 'Test/'
    datadir = settings.PROC_PATH + 'Data_Files/'
    if filetype[-1] in ['i', 's', 'h']:
        filetype2 = filetype[0:len(filetype)-1]
    else:
        filetype2 = filetype
    df_style = pd.read_csv(datadir + filetype2 + '_style_characteristics.csv',
                           sep=',', na_values=[''])
    df_restate = pd.read_csv(datadir + 'restate_data_2.csv', sep=',',
                             na_values=[''])
    restatevars = ['Restatement', 'Restate_Dir', 'Restate_Govt', 'Restate_Oth',
                   'Restate_Int']
    r_squareds = [['Year'] + restatevars]
    for testyear in xrange(yearstart + yearstep if yearstep > 0 else yearend,
                           yearend+1):
        print(testyear)
        df_lda = pd.read_csv(datadir + 'LDA/' + filetype + '_' + str(yearstep)
                             + '_' + stopword + '_LDA' + str(topics) + '_' +
                             str(testyear) + '.csv', sep=',', na_values=[''])
        dfm = pd.merge(df_style, df_lda, how='right', on='Filing')
        dfm = pd.merge(dfm, df_restate, how='left', on='Filing')
        for i in restatevars:
            dfm[i][dfm[i] != 1] = 0
        topicvars = ['Topic_' + str(i) for i in xrange(1, topics + 1)]
        for i in xrange(0, topics):
            dfm['Topic_'+str(i+1)+'n'] = dfm[topicvars].apply(lambda x:x[i]/sum(x), axis=1)
        topicvars = ['Topic_' + str(i) + 'n' for i in xrange(1, topics + 1)]
        mtopic = ' + '.join(topicvars)
        vec = []
        for restate in restatevars:
            model = smf.logit(restate + ' ~ ' + mtopic,
                              data=dfm[:][dfm['Test'] == 0])
            try:
                result = model.fit()
                vec.append(result.prsquared)
            except:
                vec.append('')
        r_squareds.append([testyear] + vec)
    with open(indir + 'Stats/Topic_Test/' + str(yearstep) + '/' + filetype +
              '_' + str(yearstep) + '_' + stopword + '_LDA' + str(topics) +
              '_rsq.csv', 'w') as f:
        writer = csv.writer(f)
        writer.writerows(r_squareds)
if __name__ == '__main__':
    stats()
