#All variables of the form:
# [Internal name, Regression usage, External (pretty) name, Description]
#Usage:
#from Z_Vars import varinit
#(vfinance, vparse, vparse_post, vstyle) = Vars.varinit()

import itertools

def varinit():
    vfinance = [['year', ('', '', '')],
        ['ebit', ('ebit', '', 'Earnings before interest and taxes, in USD')],
        ['wcap', ('wcap', '$wcap$', 'Working capital')],
        ['Firm', ('', '', 'The CIK of the firm')],
        ['mkvalt', ('mkvalt', '$mv$', 'Market value')],
        ['ni_at', ('ni_at', '$ni/ta$', 'Net income divided by total assets')],
        ['ni_revt', ('ni_revt', '$ni/rev$', 'Net income divided by revenue')],
        ['log_lt', ('log_lt', '$\\log(tl)$', 'Log of total liabilities')],
        ['lt_seq', ('lt_seq', '$tl/te$', 'Total liabilities divided by total equity')],
        ['lt_at', ('lt_at', '$tl/ta$', 'Total liabilities divided by total assets')],
        ['ltl_at', ('ltl_at', '$ltl/ta$', 'Long term liablities divided by total assets')],
        ['aq_lct', ('aq_lct', '$qa/cl$', 'Quick assets divided by current liabilities')],
        ['wcap_at', ('wcap_at', 'wcap_ta', 'Working capital divided by total assets')],
        ['rect_revt', ('rect_revt', '$rec/rev$', 'Receivables divided by revenue')],
        ['ni_ppent', ('ni_ppent', '$ni/ppe$', 'Net income divided by property, plant and equipment')],
        ['invt_at', ('invt_at', '$inv/at$', 'Inventory divided by total assets')],
        ['invt_revt', ('invt_revt', '$inv/rev$', 'Inventory divided by revenue')],
        ['revt_at', ('revt_at', '$rev/ta$', 'Revenue divided by total assets')],
        ['altz', ('altz', '$Altman Z$', 'Altman Z score')],
        ['d_revt', ('d_revt', '$\Delta rev$', 'Change in revenue')],
        ['r_rect', ('r_rect', '$\Delta rec + 1$', 'Current receivables divided by lagged receivables')],
        ['b_rect', ('b_rect', '$|\\Delta rec| > 10\\%$', '1 if the magnitude of change in receivables was more than 10\\%, else 0')],
        ['revt_m_gp', ('revt_m_gp', '$rev-gp$', 'Revenue minus gross profit')],
        ['gp_at', ('gp_at', '$gp/ta$', 'Gross profit divided by total assets')],
        ['r_gp', ('r_gp', '$\\Delta gp + 1$', 'Current gross profit divided by lagged gross profit')],
        ['b_gp', ('b_gp', '$|\\Delta gp| > 10\\%$', '1 if the magnitude of change in gross profit was more than 10\%, else 0')],
        ['log_at', ('log_at', '$\\log(ta)$', 'Log of total assets')],
        ['ppent_at', ('ppent_at', '$ppe/ta$', 'Property, plant and equipment divided by total assets')],
        ['ch_at', ('ch_at', '$cash/ta$', 'Cash divided by total assets')],
        ['act_lct', ('act_lct', '$ca/cl$', 'Current assets divided by current liabilities')],
        ['sic',('sic','$SIC code$','SIC code')]]
    #
    
    #NOTE: midNaudit is calculated on the fly in Regressions_v5_setup.py
    vdechow = [['rsst_acc', ('rsst_acc', '$RSST Accruals$', 'An extension of working capital accruals to include changes in long term operating assets and liabilities, following \citealt{richardson2005}')],
        ['chg_recv', ('chg_recv', '$\Delta Receivables$', 'Change in accounts receivable by average total assets')],
        ['chg_inv', ('chg_inv', '$\Delta Inventory$', 'Change in inventory by average total assets')],
        ['soft_assets', ('soft_assets', '$\% Soft Assets$', 'Percent of assets that are not PP\&E or cash and cash equivalents')],
        ['pct_chg_cashsales', ('pct_chg_cashsales', '$\Delta Cash Sales$', 'Percentage change in the difference of sales and change in accounts receivable')],
        ['chg_roa', ('chg_roa', '$\Delta Return On Assets$', 'Difference in earnings by average total assets')],
        ['issuance', ('issuance', '$Actual Issuance$', 'An indicator equal to 1 if the firm issued securities (debt or equity) during the year, 0 otherwise')],
        ['oplease_dum', ('oplease_dum', '$Operating Leases$', 'An indicator coded as 1 if future operating lease obligations are greater than 0')],
        ['book_mkt', ('book_mkt', '$Book\\text{-}To\\text{-}Market$', 'Book value of equity by market value of equity')],
        ['lag_sdvol', ('lag_sdvol', '$Lag (Mkt\\text{-}Adj Return)$', 'Previous year\'s buy-and-hold return minus the value-weighted market return for the same period')],  # Note: Despite the name seeming like lagged volatility, it really is lagged return.  Derives from the stata file it's pulled in from.
        ['restruct',('restruct','$Restructuring$','An indicator equal to 1 if the firm initiated a restructuring during the year, 0 otherwise')],
        ['restruct_3yr',('restruct_3yr','$Restructuring_{(-3,0)}$','An indicator equal to 1 if the firm initiated a restructuring during the prior three years (including the prior year), 0 otherwise')],
        ['merger',('merger','$Merger$','An indicator equal to 1 if the firm completed a merger during the year, 0 otherwise')],
        ['merger_3yr',('merger_3yr','$Merger_{(-3,0)}$','An indicator equal to 1 if the firm completed a merger during the prior three years (including the current year), 0 otherwise')],
        ['bigNaudit',('bigNaudit','$Big N Auditor$','An indicator equal to 1 if the firm was audited by a Big N auditor, 0 otherwise.')],
        ['midNaudit',('midNaudit','$Mid\\text{-}size auditor$','An indicator equal to 1 if the firm was audited by BDO, Grant Thornton, or McGladrey, 0 otherwise.')],
        ['cffin',('cffin','$Tot Financing$','Total financing Raised')],
        ['exfin',('exfin','$ExanteFinancing$','Net amount of new capital raised')],
        ['logtotasset',('logtotasset','$\\log(Total Assets)$','Log of total assets')]]
    
    vparse = [['year', ('', '$year$','Year of the 10-K filing')],
        ['Filing', ('', '$filing name$','10-K filing name, formatted as xxxxxxxxxx-xx-xxxxxx')],
        ['Firm', ('', '','The CIK of the firm')],
        ['fullsize', ('np.log(fullsize+1)', '$Full Size$','Log of size of the 10-K, in characters, pre parsing')],
        ['autogen_d', ('autogen_d', '$Autogenerated$', 'An indicator indicating if the 10-K was autogenerated')],
        ['xbrl', ('xbrl', '$XBRL$', 'Length of xbrl data in the 10-K, in characters')],
        ['para_tags', ('para_tags', '$Paragraph Tags$', 'Length of paragraph tags in the 10-K, in characters')],
        ['nbspaces', ('nbspaces', '$Non\text{-}Breaking Spaces$', 'Number of non-breaking spaces in the 10-K')],
        ['bullets', ('np.log(bullets+1)', '$\\log\\left(Bullets\\right)$','Log of the number of bullets used in the 10-K')],
        ['noheader_d', ('noheader_d', '$No Header$', 'An indicator indicating if the 10-K\'s header is missing')],
        ['headerlen', ('headerlen', '$Header$', 'The number of characters in the SEC header of the 10-K')],
        ['tables', ('tables', '$Tables$', 'Character length of tables in the 10-K')],
        ['tags', ('tags', '$Other Tags$', 'Tags besides xbrl, paragraphs, the header, and tables in the 10-K')],
        ['alltags', ('alltags', '$Tags$', 'The length of all html tags in the filing')],
        ['images', ('images', '$Images$', 'Images included via EDGARwiz in the 10-K')],
        ['hex', ('hex', '$Hexadecimal$', 'The number of hexadecimal characters in code in the 10-K')],
        ['spaces', ('spaces', '$Spaces$', 'The number of excess spaces in the 10-K')],
        ['pagenum', ('pagenum', '$Page Numbers$', 'Length of page number text in the 10-K, in characters')],
        ['fixedwidth1', ('fixedwidth1', '', '')],
        ['newlines', ('newlines', '$Newlines$', 'The number of excess newlines included in the 10-K')],
        ['fixedwidth2', ('fixedwidth2', '', '')],
        ['fixedwidth_d', ('fixedwidth_d', '$Fixed Width$', 'An indicator variable equal to 1 if the 10-K is formatted as a fixed width file and 0 otherwise')],
        ['nonalpha', ('nonalpha', '$Non\\text{-}Alphanumeric', 'The number of non-alphanumeric characters in the 10-K')],
        ['hyphens', ('hyphens', '$Hyphens$', 'The number of hyphens in the 10-K')],
        ['processedsize', ('processedsize', '$Parsed Size$', 'The number of characters in the 10-K after parsing')],
        ['mdalen', ('mdalen', '$MD\\&A Size$', 'Length of the MD\\&A section, 0 if missing')],
        ['mda_shortline', ('mda_shortline', '$MD\\&A Short Lines', 'Character length of lines with $<80$ characters in the MD\\&A of the 10-K')],
        ['shortline', ('shortline', '$Short Lines$', 'Character length of lines with $<80$ characters in the 10-K')]]
    
    vstyle = [['wordlen_u', ('wordlen_u', '$Word Length$', 'Mean word length, in characters')],
        ['wordlen_m', ('wordlen_m', '$Word Length (Median)$', 'Median word length, in characters')],
        ['wordlen_s', ('wordlen_s', '$Word Stddev$', 'Standard deviation of word length')],
        ['sentlen_u', ('sentlen_u', '$Sentence Length$', 'Mean sentence length, in words')],
        ['sentlen_m', ('sentlen_m', '$Sentence Length (median)$', 'Median sentence length, in words')],
        ['sentlen_s', ('sentlen_s', '$Sentence Stddev$', 'Standard deviation of sentence length')],
        ['sent_short_p', ('sent_short_p', '$Short Sentence \\%$', 'Percent of sentences with 30 or fewer words')],
        ['sent_long_p', ('sent_long_p', '$Long Sentence \\%$', 'Percent of sentences with 60 or more words')],
        ['paralen_u', ('paralen_u', '$Paragraph Length$', 'Mean paragraph length, in sentences')],
        ['paralen_m', ('paralen_m', '$Paragraph Length (median)$', 'Median paragraph  length, in sentences')],
        ['paralen_s', ('paralen_s', '$Paragraph Stddev$', 'Standard deviation of paragraph length')],
        ['active_p', ('active_p', '$\\% Active Voice$', 'The percent of sentences containing active voice')],
        ['passive_p', ('passive_p', '$\\% Passive Voice$', 'The percent of sentences containing passive voice')],
        ['lm_uncertainty_p', ('lm_uncertainty_p', '$\\% Uncertain$', 'The percent of words in the document included in the Loughran and Mcdonald (2011)\\nocite{loughran2011} uncertainty words dictionary')],
        ['hiv_abstract_p', ('hiv_abstract_p', '$\\% Abstract$', 'The percent of words in the document included in the Harvard IV abstract words dictionary')],
        ['lm_litigious_p', ('lm_litigious_p', '$\\% Litigious$', 'The percent of words in the document included in the Loughran and Mcdonald (2011)\\nocite{loughran2011} litigious words dictionary')],
        ['lm_modalstrong_p', ('lm_modalstrong_p', '$\\% Strong$', 'The percent of words in the document included in the Loughran and Mcdonald (2011)\\nocite{loughran2011} modal strong words dictionary')],
        ['lm_modalweak_p', ('lm_modalweak_p', '$\\% Weak$', 'The percent of words in the document included in the Loughran and Mcdonald (2011)\\nocite{loughran2011} modal weak words dictionary')],
        ['hiv_negative_p', ('hiv_negative_p', '$\\% Negative (H IV)$', 'The percent of words in the document included in the Harvard IV negative words dictionary')],
        ['lm_negative_p', ('lm_negative_p', '$\\% Negative$', 'The percent of words in the document included in the Loughran and Mcdonald (2011)\\nocite{loughran2011} negative words dictionary')],
        ['hiv_positive_p', ('hiv_positive_p', '$\\% Positive (H IV)$', 'The percent of words in the document included in the Harvard IV positive words dictionary')],
        ['lm_positive_p', ('lm_positive_p', '$\\% Positive$', 'The percent of words in the document included in the Loughran and Mcdonald (2011)\\nocite{loughran2011} positive words dictionary')],
        ['ari', ('ari', '$Automated Reading Index$', 'The Automated Reading Index measure of readability')],
        ['flesch_re', ('flesch_re', '$Flesch Reading Ease$', 'The Flesch Reading ease measure of readability')],
        ['fleschkincaid', ('fleschkincaid', '$Flesch Kincaid$', 'The Flesch Kincaid Grade Level measure of readability')],
        ['fog', ('fog', '$Fog$', 'The Gunning Fog Index: $0.4\\left(\\frac{W}{S} + 100\\times\\frac{W\'}{W}\\right)$, where $W$ is the number of words in the document, $S$ is the number of sentences, and $W\'$ is the number of complex words (3 or more syllables)')],
        ['smog', ('smog', '$SMOG Index$', 'The SMOG Index measure of readability')],
        ['clindex', ('clindex', '$Coleman\\text{-}Liau Index$', 'The Coleman-Liau Index: $5.88\\times \\frac{C}{W} - 29.6\\times\\frac{S}{W} - 15.8$, where $C$ is the number of characters (excluding spacing and punctuation), $W$ is the number of words in the document, and $S$ is the number of sentences')],
        ['lix', ('lix', '$LIX$', 'The LIX measure of readability by \\citealt{bjornsson1968}')],
        ['rix', ('rix', '$RIX$', 'The RIX measure of readabilit by \\citealt{anderson1983}$')],
        ['word_adj_p', ('word_adj_p', '$\\% Words: Adjectives$', 'The percent of words that are adjectives')],
        ['word_adv_p', ('word_adv_p', '$\\% Words: Adverbs$', 'The percent of words that are adverbs')],
        ['word_cnj_p', ('word_cnj_p', '$\\% Words: Conjunctions$', 'The percent of words that are conjunctions')],
        ['word_det_p', ('word_det_p', '$\\% Words: Determiners$', 'The percent of words that are determiners')],
        ['word_ex_p', ('word_ex_p', '$\\% Words: Existential$', 'The percent of words that are existential')],
        ['word_fw_p', ('word_fw_p', '$\\% Words: Foreign$', 'The percent of words that are foreign')],
        ['word_mod_p', ('word_mod_p', '$\\% Words: Modal verbs$', 'The percent of words that are modal verbs')],
        ['word_n_p', ('word_n_p', '$\\% Words: Nouns$', 'The percent of words that are nouns')],
        ['word_np_p', ('word_np_p', '$\\% Words: Proper Nouns$', 'The percent of words that are proper nouns')],
        ['word_num_p', ('word_num_p', '$\\% Words: Numbers$', 'The percent of words that are numbers')],
        ['word_pro_p', ('word_pro_p', '$\\% Words: Pronouns$', 'The percent of words that are pronouns')],
        ['word_p_p', ('word_p_p', '$\\% Words: Prepositions$', 'The percent of words that are prepositions')],
        ['word_to_p', ('word_to_p', '$\\% Words: To$', 'The percent of words that are to')],
        ['word_uh_p', ('word_uh_p', '$\\% Words: Interjections$', 'The percent of words that are interjections')],
        ['word_v_p', ('word_v_p', '$\\% Words: Verbs$', 'The percent of words that are verbs')],
        ['word_vd_p', ('word_vd_p', '$\\% Words: Past tense$', 'The percent of words that are past tense')],
        ['word_vg_p', ('word_vg_p', '$\\% Words: Present participles$', 'The percent of words that are present participles')],
        ['word_vn_p', ('word_vn_p', '$\\% Words: Past participles$', 'The percent of words that are past participles')],
        ['word_wh_p', ('word_wh_p', '$\\% Words: Wh Determiners$', 'The percent of words that are wh determiners')],
        ['tagged_words', ('tagged_words', '$Tagged Words$', 'The number of tagged words in the processed 10-K')],
        ['typetoken', ('typetoken', '$Type Token Ratio$', 'A measure of word variation: $\\frac{UW}{W}$, where $UW$ is the number of unique words in the document and $W$ is the number of words in total')],
        ['allcaps', ('allcaps', '$All Caps$', 'The number of words in all capital letters with at least 2 letters')],
        ['questionmarks', ('questionmarks', '$Question Marks$', 'The number of question marks in the processed 10-K')],
        ['exclamationpoints', ('exclamationpoints', '$Exclamation Points$', 'The number of exclamation points in the processed 10-K')],
        ['totalwords', ('totalwords', '$Total Words$', 'The total number of words in the processed 10-K')],
        ['sent_rep_p', ('sent_rep_p', '$\\% Of Sentences Repeated$', 'The percent of sentences in the processed 10-K which occur at least twice')],
        ['repetitious_p', ('repetitious_p', '$Repetitions$', 'The mean number of times each sentence is repeated in the processed 10-K')],
        ['repetitious_s', ('repetitious_s', '$Stddev Of Repetitions$', 'The standard deviation of repetitions')],
        ['benford_dev', ('benford_dev', '$Benford Deviation$','Benford deviation of all numbers in the processed 10-K')]]
    return (vfinance, vdechow, vparse, vstyle)

def regressinit():
    #altz and mkvalt removed for now
    finvars = 'ebit,ni_revt,ni_at,log_lt,ltl_at,lt_seq,lt_at,act_lct,aq_lct,\
wcap_at,invt_revt,invt_at,ni_ppent,rect_revt,revt_at,d_revt,\
r_rect,b_rect,r_gp,b_gp,gp_at,revt_m_gp,ch_at,log_at,ppent_at,wcap'.split(',')
    dechowvars = ['logtotasset','rsst_acc','chg_recv','chg_inv','soft_assets',\
'pct_chg_cashsales','chg_roa','issuance','oplease_dum','book_mkt','lag_sdvol',\
'merger','bigNaudit','midNaudit','cffin','exfin']
    # Removed noheader_d as it has no variation
    # Removed fixedwidth_d due to limited variation in early samples
    # nbspaces should likewise never be used
    stylevars = 'processedsize,sentlen_u,wordlen_s,paralen_s,repetitious_p,sentlen_s,typetoken,\
clindex,fog,active_p,passive_p,lm_negative_p,lm_positive_p,allcaps,\
exclamationpoints,questionmarks,bullets,headerlen,newlines,alltags'.split(',')
    return (finvars, dechowvars, stylevars)

def regressinit_ex():
    #altz and mkvalt removed for now
    finvars = 'ebit,ni_revt,ni_at,log_lt,ltl_at,lt_seq,lt_at,act_lct,aq_lct,\
wcap_at,invt_revt,invt_at,ni_ppent,rect_revt,revt_at,d_revt,\
r_rect,b_rect,r_gp,b_gp,gp_at,revt_m_gp,ch_at,log_at,ppent_at,wcap'.split(',')
    dechowvars = ['logtotasset','rsst_acc','chg_recv','chg_inv','soft_assets',\
'pct_chg_cashsales','chg_roa','issuance','oplease_dum','book_mkt','lag_sdvol',\
'merger','merger_3yr','bigNaudit','midNaudit','cffin','exfin','restruct',\
'restruct_3yr']
    # Removed noheader_d as it has no variation
    # Removed fixedwidth_d due to limited variation in early samples
    # nbspaces should likewise never be used
    stylevars = 'fullsize,autogen_d,xbrl,para_tags,nbspaces,bullets,noheader_d,\
headerlen,tables,tags,alltags,images,hex,spaces,pagenum,newlines,\
fixedwidth_d,nonalpha,hyphens,processedsize,shortline,wordlen_u,\
wordlen_m,wordlen_s,sentlen_u,sentlen_m,sentlen_s,sent_short_p,\
sent_long_p,paralen_u,paralen_m,paralen_s,active_p,passive_p,\
lm_uncertainty_p,hiv_abstract_p,lm_litigious_p,lm_modalstrong_p,\
lm_modalweak_p,hiv_negative_p,lm_negative_p,hiv_positive_p,\
lm_positive_p,ari,flesch_re,fleschkincaid,fog,smog,clindex,lix,rix,\
word_adj_p,word_adv_p,word_cnj_p,word_det_p,word_ex_p,word_fw_p,\
word_mod_p,word_n_p,word_np_p,word_num_p,word_pro_p,word_p_p,word_to_p,\
word_uh_p,word_v_p,word_vd_p,word_vg_p,word_vn_p,word_wh_p,\
tagged_words,typetoken,allcaps,questionmarks,exclamationpoints,\
totalwords,sent_rep_p,repetitious_p,repetitious_s,benford_dev'.split(',')
    return (finvars, dechowvars, stylevars)

def regtypeinit():
    regdef = ['T', 'D', 'F', 'S']
    #regtypes = [(1, 0, 0, 0), (0, 1, 0, 0), (1, 1, 0, 0), (0, 0, 1, 0), (1, 1, 1, 0), (1, 0, 1, 0), (0, 0, 0, 1), (1, 1, 0, 1), (1, 0, 0, 1), (0, 0, 1, 1), (1, 1, 1, 1), (1, 0, 1, 1)]
    regtypes = [(1, 0, 0, 0), (0, 0, 1, 0), (1, 0, 1, 0), (0, 0, 0, 1), (1, 0, 0, 1), (0, 0, 1, 1), (1, 0, 1, 1)]
    dvs = ['AAER', 'Restate_Oth', 'Restatement', 'Restate_Int', 'Restate_Dir', 'Restate_Govt','Restate_Ben', 'AAERU', 'Restate_Int_AA', 'Small_R', 'SEC_Inv_AA', 'Non_Clerical_AA', 'Restate_AA', 'Restate_Ben_AA', 'Restate_Z2018_AA', 'Restate_Z2018_Serious_AA', 'Misreport_KKLM', 'Restate_Int_HLM_win', 'Restate_Int_HLM_1', 'Restate_Int_Comb', 'RI_NC_AA', 'RI_NC_SI_AA', 'Restate_Int_v1_Noprox', 'Restate_Int_v2_Noprox', 'Restate_Int_v3_Noprox']
    return (regdef, regtypes, dvs)


def regname(reg, regdef):
    out = ''
    for i in xrange(0, len(reg)):
        if reg[i]:
            out += regdef[i]
    return out

def longname(spec, F):
    naming = dict([['T', 'Topic'], ['D', 'Deviation'], ['F', F[0].upper() + F[1:]], ['S', 'Style'],
                   ['TD', 'Topic and deviation'], ['TDF', 'Topic, deviation, and ' + F],
                   ['TF', 'Topic and ' + F],
                   ['TDS', 'Topic, deviation, and style'], ['FS', F[0].upper() + F[1:] + ' and style'],
                   ['TS', 'Topic and Style'], 
                   ['TDFS', 'Topic, deviation, ' + F + ', and style'],
                   ['TFS', 'Topic, ' + F + ', and style']])
    return naming[spec]

def graphinit():
    # F, T, D, S
    # stars: ['*','*','*']
    order = ['F', 'T', 'D', 'S', 'TD']
    colors = [['#ff4444', '#aa3333', '#552222'], ['#00ff00', '#00aa00', '#005500'], ['#6666ff', '#555588', '#222233'], ['#00ffff', '#00aaaa', '#005555'], ['#ff00ff', '#aa00aa', '#550055']]
    patterns = [[None,None,None], ['//','//','//'], ['\\\\','\\\\','\\\\'], ['//','//','//'], ['xx','xx','xx']]
    labels = [['Financials $p<0.05$', 'Financials $p<0.10$', 'Financials'], ['Topic $p<0.05$', 'Topic $p<0.10$', 'Topic'], ['Topic Deviation $p<0.05$', 'Topic Deviation $p<0.10$', 'Topic Deviation'], ['Style $p<0.05$', 'Style $p<0.10$', 'Style'], ['Topic and Deviation $p<0.05$', 'Topic and Deviation $p<0.10$', 'Topic and Deviation']]
    return (order, colors, patterns, labels)


def graphspec(lets):
    options = [''.join(x) for x in itertools.permutations(''.join(lets))]
    (regdef, regtypes, dvs) = regtypeinit()
    regs = []
    for reg in regtypes:
        regs.append(regname(reg, regdef))
    for reg in regs:
        if reg in options:
            return reg
    return 'Invalid input'


def graphcolor(elem,sig):
    (order, colors, patterns, leglables) = graphinit()
    for i in xrange(0, len(order)):
        if elem == order[i]:
            if sig < 0.05:
                return colors[i][2]
            elif sig < 0.1:
                return colors[i][1]
            else:
                return colors[i][0]
    return 'failed'

if __name__ == '__main__':
	varinit()
