import os, sys

def getScriptPath():
    return os.path.dirname(os.path.realpath(sys.argv[0]))

if __name__ == '__main__':
	var = getScriptPath()
	print(var)
