#!/bin/bash
# Replicates creating the LDA measure from raw 10-K filings.

# After installing NLTK using pip, you must install the brown corpus:
# $ python
# $ import nltk
# $ nltk.download
# $ nltk.download('brown')
# $ nltk.download('punkt')

cd ../Code_pre

# Parse 10-K filings into a machine readable format
# Looks for 10-Ks in ../Proc/Data_Files/Documents_Raw
python Parse_Setup.py build_ext --inplace
# Parameters:
#     6: Number of threads to use.  Required
#     10-K: File type to examine.  Defaults to 10-K
#     1994: Starting year.  Defaults to 1994
#     2012: Last year.  Defaults to 2012
python Parse_Run.py 6

# Parse out style characteristics
# Not needed to generate the LDA topics
# Parameters:
#     6: Number of threads
#     10-K: Filetype.  Defaults to 10-K
#     0: MDA flag.  Defaults to 0; 1 to process MDA instead
#python Style_Parser_Setup.py build_ext --inplace
#python Style_Parser_Run.py 6

# NOTE: This step explicitly requires providing the Unix disctionary files.
# Please grab those files and place them in '../Libraries/Dictionaries/'
# The dictionaries are detailed in '../Libraries/Dictionaries/REMOVED.txt'
# Generate word counts for every file, potentially restricting
# output to conform to a dictionary
# Parameters:
#     2: Number of threads to use for parsing
#     6: Number of threads to use for combining (more computationally intense)
#     10-K: File type to examine.  Defaults to 10-K
#     1994: Starting year. Defaults to 1994
#     2012: Last year.  Defaults to 2012
#     0: Dictionary
# Dictionaries:
# (dictionaries are /Libraries/Dictionaries/american-english*)
#    0: No dictionary filtering of words
#    1: 's': american-english (Standard Unix American English)
#    2: 'h': american-english-huge (Larger variant)
#    3: 'i': american-english-insane (Largest variant)
# Note: For small numbers of documents in a year, there is a race condition with
# respect to how quickly the threads start up.  With >>20*threads documents,
# this should never be an issue.
python Word_Counts_Setup.py build_ext --inplace
python Word_Counts_Run.py 2 6 10-K 1994 2012 0
python Word_Counts_Run.py 2 6 10-K 1994 2012 1
python Word_Counts_Run.py 2 6 10-K 1994 2012 2
python Word_Counts_Run.py 2 6 10-K 1994 2012 3

# Remove stopwords from word counts
# Parameters:
#     6: Number of threads to use
#     10-K: File type.  The s, h, and i postfixes indicate different dictionaries used
#     5: Window length to use.  Always 5 in our paper.
#     1994: Starting year
#     2012: Last year
#     50: Remove the most frequently occurring words until 50% removed
#     0: Ignore removing words based on % of files containing
#     500: Remove words that occur <= 500 times
#     100: Remove words that show up in < 100 files
#     0: For debugging only -- no need to change
# 50, 0, 500, 100, 0 are parameters controlling stopword usage.
# These are tuned using simulation later.

python Stopword_Generator_Setup.py build_ext --inplace
python Stopword_Generator_Run.py 6 10-K 5 1994 2012 50 0 500 100 0
python Stopword_Generator_Run.py 6 10-Ks 5 1994 2012 50 0 500 100 0
python Stopword_Generator_Run.py 6 10-Kh 5 1994 2012 50 0 500 100 0
python Stopword_Generator_Run.py 6 10-Ki 5 1994 2012 50 0 500 100 0
# Note:
# Optimal script was found (via simulation below) to be:
# python Stopword_Generator_Run.py 6 10-Ks 5 1994 2012 60 0 1100 100 0

#Run LDA algorithm
# Parameters:
#     6: # of processes to use
#     10-K: Dictionary filtered variants
#     5: window length
#     50-0-500-100: stopword variant
#     20: 
#     1994: first year of processed 10-K data to use
#     2012: last year of processed 10-K data to use
#     0: For debugging only -- no need to change
python LDA.py 6 10-K 5 50-0-500-100 20 1994 2012 0
python LDA.py 6 10-Ks 5 50-0-500-100 20 1994 2012 0
python LDA.py 6 10-Kh 5 50-0-500-100 20 1994 2012 0
python LDA.py 6 10-Ki 5 50-0-500-100 20 1994 2012 0
# Note:
# Optimal script was found (via simulation below) to be:
# python LDA.py 6 10-Ks 5 60-0-1100-100 31 1994 2012 0

# Convert LDA output into data files and human readable topic files
# Parameters:
#     6: # of processes to use
#     10-K: Dictionary filtered variants
#     5: window length
#     50-0-500-100: stopword variant
#     20: 
#     1994: first year of processed 10-K data to use
#     2012: last year of processed 10-K data to use
#     0: For debugging only -- no need to change
python LDA_Convert.py 6 10-K 5 50-0-500-100 20 1994 2012 0
python LDA_Convert.py 6 10-Ks 5 50-0-500-100 20 1994 2012 0
python LDA_Convert.py 6 10-Kh 5 50-0-500-100 20 1994 2012 0
python LDA_Convert.py 6 10-Ki 5 50-0-500-100 20 1994 2012 0
# Note:
# Optimal script was found (via simulation below) to be:
# python LDA_Convert.py 6 10-Ks 5 60-0-1100-100 31 1994 2012 0


# The simulation script requires access to some data.  It can
# be repurposed to run using only the data provided and the output
# from the LDA_Convert.py script above.
#Compare convergence of the four dictionary types
# Parameters:
#     10-K: Dictionary filtered variants
#     5: window length
#     50-0-500-100: stopword variant
#     20: 
#     1994: first year of processed 10-K data to use
#     2012: last year of processed 10-K data to use
#     0: For debugging only -- no need to change
python Topic_Model_Compare2.py 10-K 5 50-0-500-100 20 1994 2012 0
python Topic_Model_Compare2.py 10-Ks 5 50-0-500-100 20 1994 2012 0
python Topic_Model_Compare2.py 10-Kh 5 50-0-500-100 20 1994 2012 0
python Topic_Model_Compare2.py 10-Ki 5 50-0-500-100 20 1994 2012 0


# Now the 4 results must be compared by hand
# At this point, 10-Ks won the convergence race
#
# Next, run a convergence test to pin down the other parameters
# Note that output has been stored in separate subfolders by hand
# Also, the output has been aggregated into xlsx files by hand
# during the remedial convergence exercise.  The exercise is not
# automated, just the statistics generation.  Since the
# convergence test relies on a random sample, it is likely
# that rerunning the convergence test will yield different
# but similar results.  You will need to tweak the lines below
# to fit the results of your test.  Whenever you wil be required
# to adjust parameters, you will see the comment "#BY HAND".
# 
# The parameters used for hand tuning are provided below for convenience.
# 
# First test
for arg in 0 10 20 30 40 50 60 70 80 90
do
  python Stopword_Generator_Run.py 6 10-Ks 5 1994 2012 $arg 0 500 100 1000
  python LDA.py 6 10-K 5 $arg-0-500-100 20 1994 2012 1000
  python LDA_Convert.py 6 10-K 5 $arg-0-500-100 20 1994 2012 1000
  python Topic_Model_Compare2.py 10-K 5 $arg-0-500-100 20 1994 2012 1000
done
#BY HAND
# Determine the best run above, and then use that to set a range for
# the second round.  I tested a range around 60.
for arg in 51 52 53 54 55 56 57 58 59 61 62 63 64 65 66 67 68 69
do
  python Stopword_Generator_Run.py 6 10-Ks 5 1994 2012 $arg 0 500 100 1000
  python LDA.py 6 10-K 5 $arg-0-500-100 20 1994 2012 1000
  python LDA_Convert.py 6 10-K 5 $arg-0-500-100 20 1994 2012 1000
  python Topic_Model_Compare2.py 10-K 5 $arg-0-500-100 20 1994 2012 1000
done
#BY HAND
# Determine the best run above, use that number going forward.
# In my testing, 60 won.
#
# Second test
for arg in 100 300 500 700 900 1100 1300 1500 1700 1900
do
  python Stopword_Generator_Run.py 6 10-Ks 5 1994 2012 60 0 $arg 100 1000
  python LDA.py 6 10-K 5 60-0-$arg-100 20 1994 2012 1000
  python LDA_Convert.py 6 10-K 5 60-0-$arg-100 20 1994 2012 1000
  python Topic_Model_Compare2.py 10-K 5 60-0-$arg-100 20 1994 2012 1000
done
#BY HAND
# Determine the best run above, and then use that to set a range for
# the second round.  I tested a range around 500, 1100, and 1300.
for arg in 350 400 450 550 600 650 950 1000 1050 1150 1200 1250 1350 1400 1450
do
  python Stopword_Generator_Run.py 6 10-Ks 5 1994 2012 60 0 $arg 100 1000
  python LDA.py 6 10-K 5 60-0-$arg-100 20 1994 2012 1000
  python LDA_Convert.py 6 10-K 5 60-0-$arg-100 20 1994 2012 1000
  python Topic_Model_Compare2.py 10-K 5 60-0-$arg-100 20 1994 2012 1000
done
#BY HAND
# Determine the best run above, use that number going forward.
# In my testing, 1100 won.
#
# Third test
for arg in 0 25 50 75 100 125 150 200 250 300 400 500
do
  python Stopword_Generator_Run.py 6 10-Ks 5 1994 2012 60 0 1100 $arg 1000
  python LDA.py 6 10-K 5 60-0-1100-$arg 20 1994 2012 1000
  python LDA_Convert.py 6 10-K 5 60-0-1100-$arg 20 1994 2012 1000
  python Topic_Model_Compare2.py 10-K 5 60-0-1100-$arg 20 1994 2012 1000
done
#BY HAND
# Determine the best run above, and then use that to set a range for
# the second round. I tested a range around 100.
for arg in 80 85 90 95 105 110 115 120
do
  python Stopword_Generator_Run.py 6 10-Ks 5 1994 2012 60 0 1100 $arg 1000
  python LDA.py 6 10-K 5 60-0-1100-$arg 20 1994 2012 1000
  python LDA_Convert.py 6 10-K 5 60-0-1100-$arg 20 1994 2012 1000
  python Topic_Model_Compare2.py 10-K 5 60-0-1100-$arg 20 1994 2012 1000
done
#BY HAND
# Determine the best run above, use that number going forward.
# In my testing, 100 won.
#
# Fourth test
python Stopword_Generator_Run.py 6 10-Ks 5 1994 2012 60 0 1100 100 1000
for arg in 2 5 10 15 20 25 30 35 40 45 50 60 70 80 90 100 125 150 200
do
  python LDA.py 6 10-K 5 60-0-1100-100 $arg 1994 2012 1000
  python LDA_Convert.py 6 10-K 5 60-0-1100-100 $arg 1994 2012 1000
  python Topic_Model_Compare2.py 10-K 5 60-0-1100-100 $arg 1994 2012 1000
done
#BY HAND
# Determine the best run above, and then use that to set a range for
# the second round. I tested a range around 20 and 30.
for arg in 16 17 18 19 21 22 23 24 26 27 28 29 31 32 33 34
do
  python LDA.py 6 10-K 5 60-0-1100-100 $arg 1994 2012 1000
  python LDA_Convert.py 6 10-K 5 60-0-1100-100 $arg 1994 2012 1000
  python Topic_Model_Compare2.py 10-K 5 60-0-1100-100 $arg 1994 2012 1000
done
#BY HAND
# Determine the best run above, use that number going forward.
# In my testing, 31 won.
#
# At this point, the convergence test is done and we can generate our final data
# to use for the main analyses.  These are the optimal versions mentioned above.
python Stopword_Generator_Run.py 6 10-Ks 5 1994 2012 60 0 1100 100 0
python LDA.py 6 10-Ks 5 60-0-1100-100 31 1994 2012 0
python LDA_Convert.py 6 10-Ks 5 60-0-1100-100 31 1994 2012 0
